package com.quanda.dev;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Question {
    private String category, text, senderName;
    private int answersAmount, viewsAmount, qId;
    private Timestamp timestamp;

    public Question(int qId, String senderName, String date, String category, String text, int answersAmount, int viewsAmount){
        this.category = category;
        this.text = text;
        this.answersAmount = answersAmount;
        this.viewsAmount = viewsAmount;
        this.senderName = senderName;
        this.timestamp =  Timestamp.valueOf(date);
        this.qId = qId;
    }


    public int getAnswersAmount() {
        return answersAmount;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public String getCategory() {
        return category;
    }

    public String getText() {
        return text;
    }

    public int getViewsAmount() {
        return viewsAmount;
    }

    public String getSenderName() {
        return senderName;
    }


    @Override
    public String toString() {
        return "Question{" +
                "category='" + category + '\'' +
                ", text='" + text + '\'' +
                ", senderName='" + senderName + '\'' +
                ", answersAmount=" + answersAmount +
                ", viewsAmount=" + viewsAmount +
                ", qId=" + qId +
                ", timestamp=" + timestamp +
                '}';
    }

    public int getqId() {
        return qId;
    }
}
