package com.quanda.dev;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import org.json.JSONException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity implements BottomNavManager{
    public static boolean firstStart = true;
    public static HomeActivity homeActivity;
    private List<Question> questions;
    private QuestionListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        questions = new ArrayList<>();
        setContentView(R.layout.activity_home);
        this.homeActivity = this;
        adapter = new QuestionListAdapter(this, questions);
        ListView homeList = findViewById(R.id.homeList);

        homeList.setAdapter(adapter);


        if (firstStart) {
            firstStart = false;
            new ConnectionHandler().start();
        } else {
            try {
                ConnectionHandler.handler.loadHomeQuestions();
            } catch (JSONException | IOException e) {
                e.printStackTrace();
            }
        }


        ImageButton home = findViewById(R.id.home);
        home.setBackground(getDrawable(R.drawable.item_selected));
        TextView sectionTitle = findViewById(R.id.sectionTitle);
        sectionTitle.setText(getString(R.string.home));
    }

    public void addQuestion(Question q){
        this.questions.add(q);
    }

    public void refresh() {
        this.runOnUiThread(()->{
            adapter.notifyDataSetChanged();
        });
    }

    @Override
    public void home(View view) {
        openActivity(this, HomeActivity.class);
    }

    @Override
    public void questions(View view) {
        openActivity(this, QuestionsActivity.class);
    }

    @Override
    public void ranking(View view) {
        openActivity(this, RankingActivity.class);
    }

    @Override
    public void profile(View view) {
        openActivity(this, ProfileActivity.class);
    }
}