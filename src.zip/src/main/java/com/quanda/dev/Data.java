package com.quanda.dev;

public class Data {
    public static String PREFS_NAME = "quandaLogin";
    public static boolean isUser = false;
    public static String uuid = null;
}
