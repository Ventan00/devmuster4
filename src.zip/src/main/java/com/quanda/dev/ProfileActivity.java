package com.quanda.dev;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ProfileActivity extends AppCompatActivity implements BottomNavManager{
    public static ProfileActivity profileActivity;
    private List<Question> questions = new ArrayList<>();
    private QuestionListAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        profileActivity = this;

        if(Data.isUser) {
            try {
                displayProfile();
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
        }else {
            displayLoginAndRegister();
        }

        LinearLayout profileContainer = findViewById(R.id.profileContainer);
        profileContainer.setBackground(getDrawable(R.drawable.item_selected));
    }

    public void updateProfilData(String name,  boolean isPremium, int points, int questions, int answers) {
        this.runOnUiThread(()->{
            ((TextView)findViewById(R.id.profilName)).setText(name);
            ((TextView)findViewById(R.id.profilPoints)).setText(points + " points");
            ((TextView)findViewById(R.id.profilQuestions)).setText(String.valueOf(questions));
            ((TextView)findViewById(R.id.profilAnswers)).setText(String.valueOf(answers));
            ((TextView)findViewById(R.id.profilPremium)).setText( isPremium ? "Premium Member" : ((TextView)findViewById(R.id.profilPremium)).getText().toString());
        });
    }

    public void addQuestion(Question q) {
        this.questions.add(q);
    }

    public void refresh(){
        runOnUiThread(()->{
            adapter.notifyDataSetChanged();
        });
    }

    private void displayProfile() throws IOException, JSONException {
        setContentView(R.layout.activity_profile);

        loadList();
    }

    private void displayLoginAndRegister(){
        setContentView(R.layout.login);
    }

    private void loadList() throws IOException, JSONException {
        adapter = new QuestionListAdapter(this, questions);
        ListView profileList = findViewById(R.id.myQuestions);
        profileList.setAdapter(adapter);

        ConnectionHandler.handler.loadProfile(Data.uuid);
    }

    public void edit(View view) {
        setContentView(R.layout.edit_profile);
    }

    public void done(View view) {
        String eName = ((EditText)findViewById(R.id.eName)).getText().toString();
        String eSurname = ((EditText)findViewById(R.id.eSurname)).getText().toString();
        String eUsername = ((EditText)findViewById(R.id.eUsername)).getText().toString();
        String eContact = ((EditText)findViewById(R.id.eContact)).getText().toString();
        String eBio = ((EditText)findViewById(R.id.eBio)).getText().toString();

        if (eName.contains(" ")){
            Alert.show(findViewById(R.id.eContainer), "NAME can't contains special chars");
            return;
        }

        if (eSurname.contains(" ")){
            Alert.show(findViewById(R.id.eContainer), "SURNAME can't contains special chars");
            return;
        }

        if (eUsername.contains(" ")){
            Alert.show(findViewById(R.id.eContainer), "USERNAME can't contains special chars");
            return;
        }

        if (eName.length() <= 3 || eName.length() >= 20) {
            Alert.show(findViewById(R.id.eContainer), "NAME length must be between 3-20");
            return;
        }

        if (eSurname.length() <= 3 || eSurname.length() >= 20) {
            Alert.show(findViewById(R.id.eContainer), "Surname length must be between 3-20");
            return;
        }

        if (eUsername.length() <= 3 || eUsername.length() >= 20) {
            Alert.show(findViewById(R.id.eContainer), "Username length must be between 3-20");
            return;
        }

        if (eContact.length() >= 30) {
            Alert.show(findViewById(R.id.eContainer), "Contact length is more than 30");
            return;
        }

        if (eBio.length() >= 250) {
            Alert.show(findViewById(R.id.eContainer), "Bio length is more than 250");
            return;
        }


        Intent intent = new Intent(this, ProfileActivity.class);
        overridePendingTransition(0, 0);
        startActivity(intent);

        Alert.show(findViewById(R.id.bottom_nav), "You edited your profile");
    }

    public void cancel(View view) {
        Intent intent = new Intent(this, ProfileActivity.class);
        overridePendingTransition(0, 0);
        startActivity(intent);
    }

    @Override
    public void home(View view) { openActivity(this, HomeActivity.class); }

    @Override
    public void questions(View view) {
        openActivity(this, QuestionsActivity.class);
    }

    @Override
    public void ranking(View view) {
        openActivity(this, RankingActivity.class);
    }

    @Override
    public void profile(View view) {
        openActivity(this, ProfileActivity.class);
    }

    //Register
    public void switchToLogIn(View view) {
        setContentView(R.layout.login);
    }

    public void signUp(View view) throws JSONException, IOException {
        String rName = ((EditText)findViewById(R.id.rName)).getText().toString();
        String rSurname = ((EditText)findViewById(R.id.rSurname)).getText().toString();
        String rUsername = ((EditText)findViewById(R.id.rUsername)).getText().toString();
        String rPassword = ((EditText)findViewById(R.id.rPassword)).getText().toString();
        String rEmail = ((EditText)findViewById(R.id.rEmail)).getText().toString();

        if (rName.length() <= 2 || rName.length() >= 20){
            Alert.show(findViewById(R.id.registerPane), "Name length must be between 3-20");
            return;
        }

        if (rSurname.length() <= 2 || rSurname.length() >= 20){
            Alert.show(findViewById(R.id.registerPane), "Surname length must be between 3-20");
            return;
        }

        if (rUsername.length() <= 2 || rUsername.length() >= 20){
            Alert.show(findViewById(R.id.registerPane), "Username length must be between 3-20");
            return;
        }

        if (rPassword.length() <= 7 || rPassword.length() >= 20){
            Alert.show(findViewById(R.id.registerPane), "Password length must be between 3-20");
            return;
        }

        if (rEmail.length() <= 9 || rEmail.length() >= 40){
            Alert.show(findViewById(R.id.registerPane), "Email length must be between 10-40");
            return;
        }

        ConnectionHandler.handler.sendRegister(rName, rSurname, rUsername, rEmail, rPassword);
    }

    //Login
    public void switchToRegister(View view){
        setContentView(R.layout.register);
    }

    public void logIn(View view) throws IOException, JSONException {
        String lUsername = ((EditText)findViewById(R.id.lUsername)).getText().toString();
        String lPassword = ((EditText)findViewById(R.id.lPassword)).getText().toString();

        InputMethodManager imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);

        if (lUsername.length() <= 2 || lUsername.length() >= 20){
            Alert.show(findViewById(R.id.loginPane), "Username length must be between 3-20");
            return;
        }

        if (lPassword.length() <= 7 || lPassword.length() >= 20){
            Alert.show(findViewById(R.id.loginPane), "Password length must be between 8-20");
            return;
        }

        ConnectionHandler.handler.sendLogin(lUsername, lPassword);
    }

    public void loginError() {
        Alert.show(findViewById(R.id.loginPane), "Wrong username or password");
        return;
    }

    public void registerError() {
        Alert.show(findViewById(R.id.registerPane), "Username is already taken");
        return;
    }

    public void registerSuccess() {
        Alert.show(findViewById(R.id.loginPane), "Register complete!");
        return;
    }
}
